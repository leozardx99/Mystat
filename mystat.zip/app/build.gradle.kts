plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.mystat.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mystat.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Real phones only; drops x86/x86_64 emulator ABIs so the APK isn't bloated by ffmpeg's libs for them.
        ndk { abiFilters += setOf("arm64-v8a", "armeabi-v7a") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { jniLibs { useLegacyPackaging = false } }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    // Software H.264 (libx264) encoder — same encoder family PureStatus-style apps use,
    // so Mystat can hit an exact bitrate/profile/GOP instead of the phone's hardware encoder floor.
    // GPL-3.0 licensed because it bundles libx264; see note below.
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:8.1.8")
}
