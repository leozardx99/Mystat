package com.mystat.app

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts.PickMultipleVisualMedia
import androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// ---- Tweak here ----
private const val MAX_FILES = 3
private const val MAX_BYTES = 300L * 1024 * 1024
private const val MBPS_720 = 2.5f // video bitrate for 720p, chat only
private const val MBPS_1080 = 4f // video bitrate for 1080p, chat only
private const val AUDIO_KBPS = 128 // matches the PureStatus sample's AAC track
private const val GOP_FRAMES = 48 // ~1.5s keyframe interval, matches the PureStatus sample
private const val X264_PRESET = "medium" // libx264 speed/efficiency tradeoff; "veryfast" if encoding feels slow
private const val PHOTO_MAX_PX = 2048

private val Bg = Color(0xFF0A0F18)
private val Raised = Color(0xFF1C283B)
private val Accent = Color(0xFF8DB8FF)
private val AccentDk = Color(0xFF17315E)
private val Edge = Color(0xFF28354D)
private val Ink = Color(0xFFE6EBF5)
private val Dim = Color(0xFFA7B1C4)

private data class Media(val uri: Uri, val video: Boolean, val size: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val clear = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(SystemBarStyle.dark(clear), SystemBarStyle.dark(clear))
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) { App() } }
    }
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf(listOf<Media>()) }
    var done by remember { mutableStateOf(listOf<Uri>()) }
    var doneInfo by remember { mutableStateOf(listOf<String>()) }
    var busy by remember { mutableStateOf<String?>(null) }
    var quality by remember { mutableStateOf(768) }
    var mbps by remember { mutableStateOf(3.8f) }
    var doneBytes by remember { mutableStateOf(0L) }
    val total = picked.sumOf { it.size }
    val step = if (done.isNotEmpty()) 2 else if (picked.isNotEmpty()) 1 else 0

    val picker = rememberLauncherForActivityResult(PickMultipleVisualMedia(MAX_FILES)) { uris ->
        if (uris.isNotEmpty()) {
            picked = uris.map {
                Media(it, ctx.contentResolver.getType(it)?.startsWith("video") == true, sizeOf(ctx, it))
            }
            done = emptyList()
            doneInfo = emptyList()
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Logo()
            Spacer(Modifier.width(14.dp))
            Text("Mystat", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Icon(Icons.Default.MoreVert, null, tint = Ink)
        }
        Text("HD status, made on your phone", color = Ink, fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Medium)
        Text("No login. No server. No ads. Everything is processed right on your phone.", color = Dim, fontSize = 18.sp, lineHeight = 26.sp)

        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Node(Icons.Default.Add, "Select", step == 0); Bar()
            Node(Icons.Default.Settings, "Compress", step == 1); Bar()
            Node(Icons.AutoMirrored.Filled.Send, "Send", step == 2)
        }

        Panel(pad = 18) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = Dim)
                Spacer(Modifier.width(16.dp))
                Text(
                    busy ?: when {
                        done.isNotEmpty() -> "Done, saved to the Mystat folder:\n" + doneInfo.joinToString("\n")
                        picked.isEmpty() -> "No photos or videos selected."
                        else -> "${picked.size} selected. Ready to compress."
                    },
                    color = Ink, fontSize = 18.sp
                )
            }
        }

        Panel(fill = Raised, border = null, pad = 18) {
            Row {
                Icon(Icons.Default.Lock, null, tint = Ink)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("Private on-device processing", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text("Nothing is uploaded. Your files are compressed on this phone.", color = Dim, fontSize = 16.sp, lineHeight = 22.sp)
                }
            }
        }

        Panel {
            Head("01", "Choose media", "Pick up to $MAX_FILES photos or videos.")
            Spacer(Modifier.height(16.dp))
            Big("Choose media", Icons.Default.Add, busy == null) {
                picker.launch(PickVisualMediaRequest(PickVisualMedia.ImageAndVideo))
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("${picked.size}/$MAX_FILES files", color = Ink, fontSize = 22.sp)
                Text("${fmt(total)} / 300 MB", color = if (total > MAX_BYTES) Color(0xFFFF8A80) else Dim, fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { (total.toFloat() / MAX_BYTES).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(10.dp).clip(CircleShape),
                color = Accent, trackColor = Edge
            )
        }

        Panel {
            Head("02", "Compress to HD", "Encoded in software like PureStatus does it, not the phone's hardware encoder.")
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Ultra Safe", quality == 360) { if (busy == null) { quality = 360; mbps = 0.7f } }
                Pill("Status Safe", quality == 480) { if (busy == null) { quality = 480; mbps = 1.2f } }
                Pill("Match PureStatus", quality == 768) { if (busy == null) { quality = 768; mbps = 3.8f } }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("HD 720p", quality == 720) { if (busy == null) { quality = 720; mbps = MBPS_720 } }
                Pill("Full HD 1080p", quality == 1080) { if (busy == null) { quality = 1080; mbps = MBPS_1080 } }
            }
            Text(
                when (quality) {
                    360 -> "Smallest frame. Less necessary now that encoding runs in software, but still here as a fallback."
                    480 -> "Smaller frame, closest to what Status re-compresses to anyway."
                    768 -> "Matches the resolution and bitrate measured from a real PureStatus export. Start here."
                    else -> "Looks sharpest in chat and when forwarded to Status, but Status itself may still re-squash it."
                },
                color = Dim, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text("Bitrate: ${"%.2f".format(mbps)} Mbps", color = Ink, fontSize = 16.sp)
            Slider(
                value = mbps, onValueChange = { mbps = it }, valueRange = 0.3f..8f, steps = 76,
                enabled = busy == null,
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Edge)
            )
            Spacer(Modifier.height(16.dp))
            Big("Compress", Icons.Default.Settings, picked.isNotEmpty() && busy == null && total <= MAX_BYTES) {
                scope.launch {
                    done = emptyList()
                    val out = mutableListOf<Uri>()
                    try {
                        picked.forEachIndexed { i, m ->
                            busy = "Compressing ${i + 1}/${picked.size}..."
                            out += toHd(ctx, m, i, quality, (mbps * 1_000_000).toInt())
                        }
                        doneBytes = out.sumOf { sizeOf(ctx, it) }
                        doneInfo = out.mapIndexed { idx, u ->
                            val sz = sizeOf(ctx, u)
                            val secs = withContext(Dispatchers.IO) { durationSeconds(ctx, u) }
                            val actualMbps = if (secs > 0) (sz * 8.0 / 1_000_000.0 / secs) else 0.0
                            "File ${idx + 1}: ${fmt(sz)}" + if (secs > 0) ", ~%.2f Mbps actual (requested %.2f)".format(actualMbps, mbps) else ""
                        }
                        done = out
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Compress failed: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        busy = null
                    }
                }
            }
            if (busy != null) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape), color = Accent, trackColor = Edge)
            }
        }

        Panel {
            Head("03", "Post in full HD", "Send to WhatsApp and choose My status.")
            Spacer(Modifier.height(16.dp))
            Big("Send to WhatsApp", Icons.AutoMirrored.Filled.Send, done.isNotEmpty() && busy == null) {
                sendToWhatsApp(ctx, done)
            }
            Spacer(Modifier.height(8.dp))
            listOf(
                "Tap Send to WhatsApp and choose My status.",
                "Still blurry? Lower the bitrate in step 2, compress again and repost.",
                "Fallback: send to your own chat, long-press the video, tap Forward, choose My status. That path never re-compresses."
            ).forEachIndexed { i, s ->
                Text("${i + 1}. $s", color = Dim, fontSize = 16.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ---------- UI pieces ----------

@Composable
private fun Panel(
    fill: Color = Color.Transparent, border: Color? = Edge, pad: Int = 20,
    content: @Composable ColumnScope.() -> Unit
) {
    val s = RoundedCornerShape(28.dp)
    Column(
        Modifier.fillMaxWidth().clip(s).background(fill)
            .then(if (border != null) Modifier.border(1.dp, border, s) else Modifier)
            .padding(pad.dp),
        content = content
    )
}

@Composable
private fun Head(n: String, title: String, sub: String) = Row {
    Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(AccentDk), Alignment.Center) {
        Text(n, color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.width(16.dp))
    Column {
        Text(title, color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        Text(sub, color = Dim, fontSize = 16.sp, lineHeight = 22.sp)
    }
}

@Composable
private fun Big(text: String, icon: ImageVector, enabled: Boolean, onClick: () -> Unit) = Button(
    onClick = onClick,
    modifier = Modifier.fillMaxWidth().height(60.dp),
    enabled = enabled,
    shape = RoundedCornerShape(30.dp),
    colors = ButtonDefaults.buttonColors(
        containerColor = Accent, contentColor = Color(0xFF0A1B3A),
        disabledContainerColor = Raised, disabledContentColor = Dim
    )
) {
    Icon(icon, null)
    Spacer(Modifier.width(10.dp))
    Text(text, fontSize = 18.sp)
}

@Composable
private fun Node(icon: ImageVector, label: String, on: Boolean) =
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(if (on) Accent else Raised), Alignment.Center) {
            Icon(icon, null, tint = if (on) Color(0xFF0A1B3A) else Dim)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = if (on) Accent else Ink, fontSize = 15.sp)
    }

@Composable
private fun RowScope.Bar() =
    Box(Modifier.weight(1f).padding(top = 25.dp, start = 8.dp, end = 8.dp).height(2.dp).background(Edge))

@Composable
private fun RowScope.Pill(text: String, on: Boolean, onClick: () -> Unit) {
    val s = RoundedCornerShape(24.dp)
    Box(
        Modifier.weight(1f).height(48.dp).clip(s)
            .background(if (on) AccentDk else Color.Transparent)
            .border(1.dp, if (on) Accent else Edge, s)
            .clickable(onClick = onClick),
        Alignment.Center
    ) { Text(text, color = if (on) Accent else Ink, fontSize = 16.sp, fontWeight = FontWeight.Medium) }
}

@Composable
private fun Logo() = Box {
    Box(
        Modifier.size(54.dp).clip(RoundedCornerShape(15.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3D7BFF), Color(0xFF1B4DB5)))),
        Alignment.Center
    ) { Text("HD", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
    Icon(Icons.Default.CheckCircle, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).size(20.dp))
}

// ---------- Compression ----------

private suspend fun toHd(ctx: Context, m: Media, i: Int, q: Int, bps: Int): Uri {
    val file = File(ctx.cacheDir, "mystat_${System.currentTimeMillis()}_$i." + if (m.video) "mp4" else "jpg")
    if (m.video) encodeVideo(ctx, m.uri, file, q, bps) else withContext(Dispatchers.IO) { encodePhoto(ctx, m.uri, file) }
    return withContext(Dispatchers.IO) { saveToGallery(ctx, file, m.video).also { file.delete() } }
}

private fun encodePhoto(ctx: Context, uri: Uri, out: File) {
    val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
        val big = maxOf(info.size.width, info.size.height)
        if (big > PHOTO_MAX_PX) {
            val s = PHOTO_MAX_PX.toFloat() / big
            d.setTargetSize((info.size.width * s).toInt(), (info.size.height * s).toInt())
        }
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
    }
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
}

// True when the source's short side is already at or under q, so we skip upscaling.
private fun alreadySmallEnough(ctx: Context, uri: Uri, q: Int): Boolean {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, uri)
        fun v(k: Int) = r.extractMetadata(k)?.toIntOrNull() ?: 0
        val w = v(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
        val h = v(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
        w > 0 && h > 0 && minOf(w, h) <= q
    } catch (e: Exception) {
        false
    } finally {
        r.release()
    }
}

private fun copyToCache(ctx: Context, uri: Uri, name: String): File {
    val f = File(ctx.cacheDir, name)
    ctx.contentResolver.openInputStream(uri)!!.use { input -> f.outputStream().use { input.copyTo(it) } }
    return f
}

// Software H.264 encode via libx264 (ffmpeg-kit) — this is what lets Mystat hit an exact
// bitrate/profile/GOP instead of being capped by the phone's hardware encoder's own floor,
// matching how the PureStatus sample video (encoder tag: Lavc/libx264) was built.
private suspend fun encodeVideo(ctx: Context, uri: Uri, out: File, q: Int, bps: Int) {
    val input = withContext(Dispatchers.IO) { copyToCache(ctx, uri, "mystat_src_${System.currentTimeMillis()}.tmp") }
    try {
        val skipScale = withContext(Dispatchers.IO) { alreadySmallEnough(ctx, uri, q) }
        // Short-side scale that works for both portrait and landscape sources, no upscale.
        val scale = if (skipScale) "" else "scale='if(gt(iw,ih),-2,$q)':'if(gt(iw,ih),$q,-2)',"
        val kbps = bps / 1000
        val cmd = "-y -i \"${input.absolutePath}\" " +
            "-vsync cfr " + // force constant frame rate — phone footage is often variable-rate even at a "steady" 30fps
            "-vf \"${scale}format=yuv420p\" " +
            "-c:v libx264 -profile:v high -preset $X264_PRESET " +
            "-b:v ${kbps}k -minrate ${kbps}k -maxrate ${kbps}k -bufsize ${kbps}k " + // hard CBR, no burst headroom
            "-g $GOP_FRAMES -keyint_min $GOP_FRAMES -sc_threshold 0 " +
            "-c:a aac -b:a ${AUDIO_KBPS}k -ar 44100 -ac 2 " +
            "-movflags +faststart " +
            "\"${out.absolutePath}\""
        suspendCancellableCoroutine<Unit> { c ->
            val session = FFmpegKit.executeAsync(cmd) { s ->
                if (ReturnCode.isSuccess(s.returnCode)) c.resume(Unit)
                else c.resumeWithException(RuntimeException(s.failStackTrace ?: "ffmpeg failed, code ${s.returnCode}"))
            }
            c.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
        }
    } finally {
        input.delete()
    }
}

// ---------- Save + share ----------

private fun saveToGallery(ctx: Context, f: File, video: Boolean): Uri {
    val cv = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
        put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
        put(MediaStore.MediaColumns.RELATIVE_PATH, (if (video) "Movies" else "Pictures") + "/Mystat")
    }
    val col = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    val uri = ctx.contentResolver.insert(col, cv)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    return uri
}

private fun sendToWhatsApp(ctx: Context, uris: List<Uri>) {
    val single = uris.size == 1
    val base = Intent(if (single) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
        type = "*/*"
        if (single) putExtra(Intent.EXTRA_STREAM, uris[0])
        else putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
        try {
            ctx.startActivity(Intent(base).setPackage(pkg))
            return
        } catch (_: ActivityNotFoundException) {
        }
    }
    Toast.makeText(ctx, "WhatsApp not found", Toast.LENGTH_SHORT).show()
}

private fun durationSeconds(ctx: Context, u: Uri): Double {
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(ctx, u)
        (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
    } catch (e: Exception) {
        0.0
    } finally {
        r.release()
    }
}

private fun sizeOf(c: Context, u: Uri): Long =
    c.contentResolver.query(u, arrayOf(OpenableColumns.SIZE), null, null, null)
        ?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L

private fun fmt(b: Long) =
    if (b >= 1_048_576) "%.1f MB".format(b / 1_048_576.0) else "%.1f KB".format(b / 1024.0)
